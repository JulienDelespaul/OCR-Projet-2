# OCR-Projet-2

Projet réalisé dans le cadre de la formation développeur web d'OpenClassrooms

- Intégration des maquettes desktop et mobile fournies
- Création de la version tablette

Containtes techniques

- uniquement CSS et HTML, pas de framework
- dispositon en flex, pas de grid
- margins et paddings en pixels,
- widths en pourcentages
- pas de rem, em
